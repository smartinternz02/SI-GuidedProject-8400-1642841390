package com.shailaja.SpringExpenseTracker.SpringExpenseTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExpenseTrackerTests {

	@Test
	void contextLoads() {
	}

}
